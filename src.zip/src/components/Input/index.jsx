import React from "react";

const index = () => {
  return (
    <>
      <input type="text" />
    </>
  );
};

export default index;
