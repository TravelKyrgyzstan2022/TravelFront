export const ROLES = {
  admin: "ROLE_ADMIN",
  user: "ROLE_USER",
  superAdmin: "ROLE_SUPERADMIN",
};
