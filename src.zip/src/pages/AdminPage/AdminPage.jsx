import React from "react";
import SideBar from "../../components/SideBar";

const AdminPage = () => {
  return (
    <>
      <SideBar />
    </>
  );
};

export default AdminPage;
