import AlaToo from "./ala_too.png";

export { AlaToo };
